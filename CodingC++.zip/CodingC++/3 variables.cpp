#include <stdio.h>
#include <stdlib.h>

int main() {
    int a = 3, b = 4, c = 5; 
    int resultado = a * b * c; 

    printf("El resultado de la multiplicacion es: %d\n", resultado);

    system("Pause");
    return 0;
}
