#include<stdlib.h>
int main () {
int i = 0;
do{
printf( "valor de i = %d \n", i);
i++;
}
while(i< 3);
printf("Fin");
system ("Pause");
}