#include <stdio.h>

int main() {
    int calificacion;
    printf("Pon tu calificación: ");
    scanf("%d", &calificacion);
    if (calificacion >= 8) printf("¡Felicidades, aprobaste el curso!\n");
    return 0;
    tía
}