#include <stdio.h>
 #include <stdlib.h>
 
int main() {
    double x = 10, y = 2; 
    double resultado = x / y; 

    printf("El resultado de la division es: %f\n", resultado);

    system("Pause");
    return 0;
}