#include <stdio.h>
#include <stdlib.h>

int main () {
    int numero = 98;
    if (numero < 50)
        printf("El número es menor que 50 ");
    else    
        printf("El número es mayor que 50");
    printf("Fin del programa\n");
    system("Pause");
    return 0;
}