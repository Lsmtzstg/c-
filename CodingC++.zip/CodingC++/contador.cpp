#include <stdio.h>
#include <stdlib.h>
int main() {
    int contador = 0;
    while (contador < 3) {
        printf("Hola\n");
        contador++;
    }
    printf("Fin");
    system("Pause");
}